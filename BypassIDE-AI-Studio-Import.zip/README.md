# Bypass IDE — Android + GitHub reconstruction workspace

This repository contains a **buildable Kotlin/Jetpack Compose starter reconstruction** and evidence extracted from the supplied APK. It is not yet a byte-for-byte or feature-complete source recovery.

## What is included
- Android Studio Gradle project (`app/`).
- Clean launcher UI scaffold under the recovered package namespace.
- APK-derived API/feature inventory in `docs/`.
- Original uploaded APK and DEX string-table evidence in `recovered-original/`.

## Evidence-based observations
The APK contains two DEX files and strings referencing `com.bypass.ide`, `BypassIdeApp`, `MainActivity`, Gemini streaming, DuckDuckGo, Wikipedia, public-IP endpoints, Sora editor classes, a voice wake-word service, and `/sdcard/BypassProjects`. See `docs/API-AND-FEATURE-INVENTORY.md`.

## Build
1. Open this folder in Android Studio.
2. Use JDK 17 and Android SDK 35.
3. Allow Gradle to sync dependencies.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).

## GitHub upload from Android
Create a new empty GitHub repository. Upload the contents of this folder (not the ZIP file) using GitHub's web interface, or use the GitHub mobile app/browser upload flow. Do not upload API keys.

## Recovery limitations
DEX string extraction is not full decompilation. Exact Kotlin source, Compose screen tree, original control flow, and backend implementation have not been recovered in this package. The original APK is preserved for further JADX/apktool analysis. Decompiled code may require manual repair and will not necessarily rebuild unchanged.

## Safety / privacy
This reconstruction does not implement covert monitoring, unauthorized account access, bypassing third-party controls, or stealth network interception. VPN/proxy support must be implemented transparently with explicit user consent and a legitimate VPN service configuration.
