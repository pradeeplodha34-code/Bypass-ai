# Recovery status

- [x] Original APK preserved
- [x] APK ZIP contents inspected
- [x] Two DEX files identified
- [x] DEX string tables extracted
- [x] Package / application / activity names identified from manifest string data
- [x] Network endpoint references inventoried
- [x] Android Studio starter project created
- [ ] Full JADX Java/Kotlin decompilation
- [ ] Resource XML decoding and asset mapping
- [ ] Original UI reconstruction and behavior validation
- [ ] Backend source recovery (not possible from client APK unless backend source was bundled)
- [ ] Device build and runtime test

Status: partial static recovery + buildable reconstruction scaffold.
