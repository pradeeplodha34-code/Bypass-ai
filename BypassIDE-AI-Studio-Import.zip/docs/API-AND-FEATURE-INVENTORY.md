# APK-derived API and feature inventory

The following strings were observed in the uploaded APK's DEX string tables. A string reference does not prove that a service currently works or that every code path is reachable.

## API / network URL references
- Gemini: `gemini-2.0-flash:streamGenerateContent?alt=sse&key=`
- DuckDuckGo JSON: `https://api.duckduckgo.com/?q=`
- DuckDuckGo HTML: `https://html.duckduckgo.com/html/?q=`
- DuckDuckGo Lite: `https://lite.duckduckgo.com/lite/`
- Wikipedia API: `https://en.wikipedia.org/w/api.php?action=query&list=search&srsearch=`
- IP check: `https://api.ipify.org`
- IP check: `https://icanhazip.com`
- IP check: `https://ifconfig.me/ip`
- Connectivity check: `https://www.google.com/generate_204`
- Local development URL string: `http://127.0.0.1:8080/`

## Other observed strings
- Package namespace: `com.bypass.ide`
- Application class: `com.bypass.ide.BypassIdeApp`
- Launcher activity: `com.bypass.ide.MainActivity`
- Voice service: `com.bypass.ide.voice.WakeWordService`
- Project workspace: `/sdcard/BypassProjects`
- Gemini engine error strings and network/IP shield settings references
- Sora editor classes (`io.github.rosemoe.sora`)
- UI labels include VPN-key icons and IP reset / network shield references

## Not established from string extraction alone
- Whether an operational VPN tunnel is implemented, or which VPN protocol/server it uses.
- Any private backend source code or server-side database.
- Working credentials, API keys, or secrets.
- Exact screen layouts, navigation, event handlers, or all method bodies.
- Whether IP reset means a local network action, proxy change, or remote service operation.

Never publish private API keys. Use your own authorized Gemini key in local configuration; do not commit it.
