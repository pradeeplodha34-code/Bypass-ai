package com.bypass.ide

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

/** Reconstructed starter UI. This is not a decompiled copy of the original MainActivity. */
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { HomeScreen() } }
    }
}

@Composable
private fun HomeScreen() {
    var prompt by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("Reconstructed workspace ready") }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Bypass IDE", style = MaterialTheme.typography.headlineMedium)
        Text("Android reconstruction workspace", style = MaterialTheme.typography.bodyMedium)
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("AI assistant", style = MaterialTheme.typography.titleLarge)
                OutlinedTextField(value = prompt, onValueChange = { prompt = it }, label = { Text("Enter a coding prompt") }, modifier = Modifier.fillMaxWidth(), minLines = 3)
                Button(onClick = { status = if (prompt.isBlank()) "Enter a prompt first" else "Connect a Gemini API key in Settings before sending." }) { Text("Prepare request") }
                Text(status, style = MaterialTheme.typography.bodySmall)
            }
        }
        Text("Recovered feature references", style = MaterialTheme.typography.titleLarge)
        listOf("Gemini streaming endpoint reference", "DuckDuckGo web search references", "Wikipedia search references", "Public IP lookup references", "Sora code editor library references", "Voice / wake-word service declarations").forEach { label ->
            ElevatedCard(Modifier.fillMaxWidth()) { Text(label, Modifier.padding(14.dp)) }
        }
        Text("This project is a clean, buildable reconstruction scaffold. Original screens and runtime behavior still require full DEX decompilation and validation.", style = MaterialTheme.typography.bodySmall)
    }
}
